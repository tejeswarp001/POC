package com.deloitte.utils;

import java.io.File;

public class Constants {

	public static String MONITORED_BY;

	public static final File FILE_PATH = new File("src\\main\\resources\\");

	public static final String TEMPLATE_FILE_NAME = "1PPC_Application_Report_temp.xlsx";

	public static String MYSQL_USER_NAME;

	public static String MYSQL_PASSWORD;

	public static String MYSQL_DATABASE_NAME;
	
	public static String LOG_FILE_NAME;

	static {
		MONITORED_BY = ReadProperty.readProperty(FILE_PATH + "/application.properties", "monitored_by");
		MYSQL_USER_NAME = ReadProperty.readProperty(FILE_PATH + "/application.properties", "sql_user_name");
		MYSQL_PASSWORD = ReadProperty.readProperty(FILE_PATH + "/application.properties", "sql_password");
		MYSQL_DATABASE_NAME = ReadProperty.readProperty(FILE_PATH + "/application.properties", "sql_database_name");
		LOG_FILE_NAME = ReadProperty.readProperty(FILE_PATH + "/application.properties", "logging_file");
	}
}
