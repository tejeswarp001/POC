package com.deloitte.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadProperty {
	public static String readProperty(String propertyFileName, String property) {
		FileReader reader = null;
		try {
			reader = new FileReader(propertyFileName);
			Properties p = new Properties();
			p.load(reader);

			return p.getProperty(property);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "Cann't able to read " + propertyFileName + " file";
	}
}
