package com.deloitte.utils;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.springframework.stereotype.Component;

@Component
public class LoggerUtils {

	/**
	 * 
	 * @param message
	 *            logs message in log file
	 */
	public void logMessage(String message) {
		try {
			boolean append = true;
			FileHandler handler = new FileHandler(Constants.FILE_PATH + "\\logs\\" + Constants.LOG_FILE_NAME, append);
			handler.setFormatter(new SimpleFormatter());
			
			Logger logger = Logger.getLogger(LoggerUtils.class.getName());
			logger.addHandler(handler);
			logger.setUseParentHandlers(false);

			logger.info(message);

			handler.close();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
