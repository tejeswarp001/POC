package com.deloitte.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

	@Autowired
	private JavaMailSender emailSender;

	public void sendSimpleMessage() {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("Test Sub");
		message.setText("Test Text");
		message.setTo("axat.singh@kroger.com");
		message.setFrom("shubham.gupta@kroger.com");

		emailSender.send(message);
	}
}
