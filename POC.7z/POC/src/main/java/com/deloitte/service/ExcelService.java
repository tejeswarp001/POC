package com.deloitte.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.utils.Constants;
import com.deloitte.utils.LoggerUtils;

@Service
public class ExcelService {

	@Autowired
	LoggerUtils loggerUtils;

	public void createExcel() {
		String outputFileName = getFileName();// "1PPC_Application_Report.xlsx"
		File outputFile = new File(Constants.FILE_PATH + "\\Reports\\" + outputFileName);
		copyFileTo(outputFile);

		try {
			FileInputStream inputStream = new FileInputStream(outputFile);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheet("Sheet1");

			sheet.getRow(3).getCell(2).setCellValue("Test Data");
			sheet.getRow(4).getCell(2).setCellValue("Test Data");

			sheet.getRow(1).getCell(2).setCellValue(Constants.MONITORED_BY);

			FileOutputStream outputStream = new FileOutputStream(outputFile);
			workbook.write(outputStream);
			outputStream.close();

			loggerUtils.logMessage("Data written successfully in " + outputFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String getFileName() {
		Date date = new Date();
		DateFormat formatter = new SimpleDateFormat("MM-dd-YYYY_HH-mm-ss_a");
		String fileName = "1PPC_Application_Report_" + formatter.format(date) + ".xlsx";

		return fileName;
	}

	public void copyFileTo(File outputFile) {
		File templateFile = new File(Constants.FILE_PATH + "\\Templates\\" + Constants.TEMPLATE_FILE_NAME);
		try {
			FileUtils.copyFile(templateFile, outputFile);
			loggerUtils.logMessage(outputFile + " file created");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
