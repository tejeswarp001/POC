package com.deloitte.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.service.EmailService;
import com.deloitte.service.ExcelService;
import com.deloitte.utils.LoggerUtils;

@RestController
@RequestMapping("poc")
public class MyControllers {

	@Autowired
	EmailService email;

	@Autowired
	ExcelService excelService;

	@Autowired
	LoggerUtils loggerUtils;

	@GetMapping("/excel")
	public String excelReport() {
		excelService.createExcel();

		loggerUtils.logMessage("Response Sending...");
		System.out.println("Response Sending...");

		return "Excel Created";
	}

	@GetMapping("/email")
	public String sendEmail() {
		email.sendSimpleMessage();
		return "Email Sent";
	}
}