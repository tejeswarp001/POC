package com.deloitte.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.deloitte.utils.Constants;

public class JdbcConnection {

	public static void main(String args[]) {
		Integer count = getNumOfRecords();
		System.out.println("Number of records: " + count);
	}

	public static Integer getNumOfRecords() {
		Integer count = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + Constants.MYSQL_DATABASE_NAME,
					Constants.MYSQL_USER_NAME, Constants.MYSQL_PASSWORD);

			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select count(*) from users");
			if (rs.next()) {
				count = rs.getInt(1);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return count;
	}
}
